﻿using System;


public class Program
{
    static void Main()
    {
        for (int i = 0; i < 1; i++)
        {
            string[] args = Console.ReadLine().Split();
            var person = new Person();
            person.Age= int.Parse(args[1]);
            person.Name = args[0];

            Console.WriteLine(person.ToString()); 
        }
    }
}

