﻿using System;

public class Program
{
    public static void Main()
    {
        string date1 = Console.ReadLine();
        string date2 = Console.ReadLine();

        DateModifier.DateDifference(date1, date2);
    }
}

